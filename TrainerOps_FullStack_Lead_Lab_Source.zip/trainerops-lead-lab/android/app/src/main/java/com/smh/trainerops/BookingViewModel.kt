package com.smh.trainerops

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import java.util.UUID

data class TrainingSession(val id: String, val title: String, val capacity: Int, val confirmed: Int)
sealed interface UiState { data object Loading : UiState; data class Content(val sessions: List<TrainingSession>, val stale: Boolean) : UiState; data class Error(val message: String) : UiState }
interface SessionRepository { suspend fun sessions(): Pair<List<TrainingSession>, Boolean>; suspend fun book(id: String, idempotencyKey: String) }
class BookingViewModel(private val repository: SessionRepository) : ViewModel() {
 private val _state = MutableStateFlow<UiState>(UiState.Loading); val state: StateFlow<UiState> = _state
 fun load() = viewModelScope.launch { runCatching { repository.sessions() }.onSuccess { _state.value = UiState.Content(it.first, it.second) }.onFailure { _state.value = UiState.Error("Could not load sessions. Try again.") } }
 fun book(sessionId: String) = viewModelScope.launch { if (_state.value is UiState.Loading) return@launch; runCatching { repository.book(sessionId, UUID.randomUUID().toString()) }.onSuccess { load() }.onFailure { _state.value = UiState.Error("Booking was not confirmed. Please retry.") } }
 companion object {
  fun factory(repository: SessionRepository) = object : ViewModelProvider.Factory {
   @Suppress("UNCHECKED_CAST") override fun <T : ViewModel> create(modelClass: Class<T>): T = BookingViewModel(repository) as T
  }
 }
}

class PreviewSessionRepository : SessionRepository {
 private val items = mutableListOf(
  TrainingSession("strength", "Strength Foundations", 8, 5),
  TrainingSession("mobility", "Mobility Reset", 12, 11),
  TrainingSession("performance", "Performance Coaching", 4, 2)
 )
 override suspend fun sessions() = items.toList() to false
 override suspend fun book(id: String, idempotencyKey: String) {
  val index = items.indexOfFirst { it.id == id }
  require(index >= 0 && items[index].confirmed < items[index].capacity) { "Session is full" }
  items[index] = items[index].copy(confirmed = items[index].confirmed + 1)
 }
}
