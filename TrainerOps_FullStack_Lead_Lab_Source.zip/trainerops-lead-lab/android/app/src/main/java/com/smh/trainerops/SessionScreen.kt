package com.smh.trainerops
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun SessionScreen(viewModel: BookingViewModel) {
 val state by viewModel.state.collectAsState()
 LaunchedEffect(Unit) { viewModel.load() }
 Scaffold(topBar = { TopAppBar(title = { Text("TrainerOps") }) }) { padding ->
  when (val screen = state) {
   UiState.Loading -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
   is UiState.Error -> Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) { Text(screen.message) }
   is UiState.Content -> LazyColumn(contentPadding = padding) {
    if (screen.stale) item { Text("Showing cached schedule", Modifier.padding(16.dp)) }
    items(screen.sessions, key = { it.id }) { session ->
     ListItem(
      headlineContent = { Text(session.title) },
      supportingContent = { Text("${session.confirmed} of ${session.capacity} booked") },
      trailingContent = { Button(onClick = { viewModel.book(session.id) }, enabled = session.confirmed < session.capacity) { Text("Book") } }
     )
     HorizontalDivider()
    }
   }
  }
 }
}
