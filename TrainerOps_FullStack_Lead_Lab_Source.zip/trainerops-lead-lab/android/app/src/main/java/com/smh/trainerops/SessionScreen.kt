package com.smh.trainerops
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

private enum class DashboardRole(val label: String, val headline: String, val subtitle: String) {
 Client("Client", "Move better today.", "Book sessions and manage your credits"),
 Trainer("Trainer", "Your coaching day.", "Plan your day and prepare for clients"),
 Studio("Studio", "Studio pulse.", "Monitor capacity and operational health")
}

private enum class AppTab(val label: String, val symbol: String) {
 Home("Home", "⌂"), Schedule("Schedule", "▣"), Activity("Activity", "↗"), Profile("Profile", "●")
}

@Composable
@OptIn(ExperimentalMaterial3Api::class)
fun SessionScreen(viewModel: BookingViewModel) {
 val state by viewModel.state.collectAsState()
 val bookingSessionId by viewModel.bookingSessionId.collectAsState()
 var role by remember { mutableStateOf(DashboardRole.Client) }
 var tab by remember { mutableStateOf(AppTab.Home) }
 LaunchedEffect(Unit) { viewModel.load() }
 Scaffold(
  topBar = { TopAppBar(title = { Text(if (tab == AppTab.Home) "TrainerOps" else tab.label) }, actions = { TextButton(onClick = viewModel::load) { Text("Refresh") } }) },
  bottomBar = { NavigationBar { AppTab.entries.forEach { item -> NavigationBarItem(selected = tab == item, onClick = { tab = item }, icon = { Text(item.symbol) }, label = { Text(item.label) }) } } }
 ) { padding ->
  LazyColumn(modifier = Modifier.fillMaxSize().padding(padding), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
   when (tab) {
    AppTab.Home -> {
     item { Hero(role) }
     item { Text("Live schedule · Dubai GST", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.secondary) }
     item { RoleTabs(role) { role = it } }
     item { Metrics(role) }
     item { Text(if (role == DashboardRole.Trainer) "Today’s schedule" else "Recommended sessions", style = MaterialTheme.typography.titleLarge) }
     scheduleItems(state, role, bookingSessionId, viewModel)
    }
    AppTab.Schedule -> {
     item { Text("Your schedule", style = MaterialTheme.typography.headlineSmall) }
     item { Text("Upcoming classes, capacity and waitlist actions", color = MaterialTheme.colorScheme.onSurfaceVariant) }
     scheduleItems(state, role, bookingSessionId, viewModel)
    }
    AppTab.Activity -> {
     item { Text("Weekly activity", style = MaterialTheme.typography.headlineSmall) }
     item { Metric(Triple("Completion", "92%", "11 of 12 sessions"), Modifier.fillMaxWidth()) }
     item { Metric(Triple("Next goal", "3", "sessions to unlock badge"), Modifier.fillMaxWidth()) }
    }
    AppTab.Profile -> {
     item { ProfileCard(role) }
    }
   }
  }
 }
}

private fun androidx.compose.foundation.lazy.LazyListScope.scheduleItems(state: UiState, role: DashboardRole, bookingSessionId: String?, viewModel: BookingViewModel) {
 when (state) {
  UiState.Loading -> item { ScheduleLoader() }
  is UiState.Error -> item { Column(verticalArrangement = Arrangement.spacedBy(10.dp)) { Text(state.message, color = MaterialTheme.colorScheme.error); Button(onClick = viewModel::load) { Text("Try again") } } }
  is UiState.Content -> {
   if (state.stale) item { AssistChip(onClick = {}, label = { Text("Showing cached schedule") }) }
   items(state.sessions, key = { it.id }) { session -> SessionCard(session, role, bookingSessionId == session.id) { viewModel.book(session.id) } }
  }
 }
}

@Composable private fun Hero(role: DashboardRole) {
 Surface(shape = RoundedCornerShape(24.dp), color = Color(0xFF273CBB), modifier = Modifier.fillMaxWidth()) {
  Column(Modifier.padding(20.dp)) {
   Text("GOOD EVENING", style = MaterialTheme.typography.labelMedium, color = Color.White.copy(alpha = .72f))
   Spacer(Modifier.height(7.dp)); Text(role.headline, style = MaterialTheme.typography.headlineSmall, color = Color.White)
   Text(role.subtitle, style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = .84f))
  }
 }
}

@Composable private fun RoleTabs(selected: DashboardRole, onSelect: (DashboardRole) -> Unit) {
 SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
  DashboardRole.entries.forEachIndexed { index, role ->
   SegmentedButton(selected = selected == role, onClick = { onSelect(role) }, shape = SegmentedButtonDefaults.itemShape(index = index, count = DashboardRole.entries.size), label = { Text(role.label) })
  }
 }
}

@Composable private fun ProfileCard(role: DashboardRole) {
 Surface(shape = RoundedCornerShape(22.dp), tonalElevation = 2.dp, modifier = Modifier.fillMaxWidth()) {
  Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
   Text("Aisha Rahman", style = MaterialTheme.typography.headlineSmall)
   Text("Dubai, United Arab Emirates", color = MaterialTheme.colorScheme.onSurfaceVariant)
   HorizontalDivider()
   Text("${role.label} workspace", style = MaterialTheme.typography.titleMedium)
   Text("Notifications enabled · Secure account", color = MaterialTheme.colorScheme.onSurfaceVariant)
  }
 }
}

@Composable private fun Metrics(role: DashboardRole) {
 val first = when (role) { DashboardRole.Client -> Triple("Credits", "8", "2 expire in 14 days"); DashboardRole.Trainer -> Triple("Today", "6", "sessions planned"); DashboardRole.Studio -> Triple("Bookings", "42", "today") }
 val second = when (role) { DashboardRole.Client -> Triple("Streak", "4", "weeks active"); DashboardRole.Trainer -> Triple("Fill rate", "82%", "this week"); DashboardRole.Studio -> Triple("Waitlist", "5", "needs action") }
 Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) { Metric(first, Modifier.weight(1f)); Metric(second, Modifier.weight(1f)) }
}

@Composable private fun Metric(metric: Triple<String, String, String>, modifier: Modifier) {
 Surface(shape = RoundedCornerShape(16.dp), tonalElevation = 2.dp, modifier = modifier) { Column(Modifier.padding(15.dp)) { Text(metric.first, style = MaterialTheme.typography.labelMedium); Text(metric.second, style = MaterialTheme.typography.headlineSmall, color = MaterialTheme.colorScheme.primary); Text(metric.third, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) } }
}

@Composable private fun SessionCard(session: TrainingSession, role: DashboardRole, isBooking: Boolean, onBook: () -> Unit) {
 val full = session.confirmed >= session.capacity
 Surface(shape = RoundedCornerShape(18.dp), tonalElevation = 1.dp, modifier = Modifier.fillMaxWidth()) {
  Column(Modifier.padding(17.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
   Row { Text(if (full) "WAITLIST" else "${session.capacity - session.confirmed} SPOTS", style = MaterialTheme.typography.labelMedium, color = if (full) Color(0xFFD97706) else Color(0xFF128C58)); Spacer(Modifier.weight(1f)); Text("Downtown Studio", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
   Text(session.title, style = MaterialTheme.typography.titleMedium)
   Text("${session.confirmed} of ${session.capacity} booked · 50 min", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
   if (role == DashboardRole.Client) Button(onClick = onBook, enabled = !isBooking, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = if (full) Color(0xFFD97706) else MaterialTheme.colorScheme.primary)) { if (isBooking) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = Color.White) else Text(if (full) "Join waitlist" else "Reserve session") } else Text(if (role == DashboardRole.Trainer) "Client notes and attendance ready" else "Capacity and trainer coverage monitored", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
  }
 }
}

@Composable private fun ScheduleLoader() {
 Column(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth()) {
  repeat(3) { Surface(shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) { LinearProgressIndicator(modifier = Modifier.fillMaxWidth()); Text("Loading live schedule…", style = MaterialTheme.typography.bodyMedium) } } }
 }
}
