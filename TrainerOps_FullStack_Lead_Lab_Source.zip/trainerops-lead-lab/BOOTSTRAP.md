# Bootstrap the TrainerOps Lead Lab

This repository is a **framework-ready reference implementation**. Source files are included; generated framework files, signing material, `.env` secrets, and third-party credentials are deliberately excluded.

## 1. Laravel API and MySQL

Install PHP 8.3+, Composer, Docker Desktop, and the Laravel installer. Create the standard Laravel skeleton, then copy the supplied modules into it:

```bash
composer create-project laravel/laravel trainerops-api
cd trainerops-api
cp -R ../trainerops-lead-lab/backend/app ./app
cp -R ../trainerops-lead-lab/backend/routes ./routes
cp -R ../trainerops-lead-lab/backend/database ./database
cp ../trainerops-lead-lab/backend/docker-compose.yml ./docker-compose.yml
cp .env.example .env
```

Set `DB_CONNECTION=mysql`, `DB_HOST=mysql`, `DB_DATABASE=trainerops`, `DB_USERNAME=trainerops`, and a new local `DB_PASSWORD` in `.env`. Then:

```bash
docker compose up -d
php artisan key:generate
php artisan migrate
php artisan test
php artisan serve
```

Create an authenticated user/token using your chosen Laravel Sanctum flow before calling `POST /api/v1/bookings`. Never commit `.env`, certificates, or API keys.

## 2. iOS (SwiftUI)

1. In Xcode, choose **File > New > Project > iOS App**.
2. Name it `TrainerOps`, select **SwiftUI**, **Swift**, and a deployment target appropriate for your team (iOS 17 is a good lab baseline).
3. Drag `ios/TrainerOps/App`, `Domain`, `Data`, and `Presentation` into the generated project, selecting **Copy items if needed**.
4. Update `APIClient.baseURL` to your local HTTPS API endpoint. For device testing, use a reachable development server rather than `localhost`.
5. Add Keychain storage for tokens and an app-specific configuration file ignored by Git. Then build and run from Xcode.

## 3. Android (Kotlin + Jetpack Compose)

1. In Android Studio, create **Empty Activity** using Kotlin and Jetpack Compose; use min SDK 26+ for this lab.
2. Copy `android/app/src/main/java/com/smh/trainerops` into the matching package.
3. Add the AndroidX Lifecycle ViewModel and Compose Material dependencies through Android Studio’s dependency suggestions or your version catalog.
4. Replace the sample repository with a Retrofit/OkHttp implementation that uses HTTPS, timeouts, interceptors, and secure token storage.
5. Build with `./gradlew test` and run on an emulator or physical device.

## What the lab demonstrates

- SwiftUI and Compose screens call a presentation-layer ViewModel, not networking directly.
- The Laravel booking service uses validation, authentication, idempotency, transactions, row locks, and capacity checks.
- MySQL models bookings, sessions, trainers, roles, subscriptions, and audit events.

It is intentionally not a deployable copy of any employer product. Before production, add complete authorization policies, telemetry, CI/CD, secret management, monitoring, load tests, accessibility tests, app-store release configuration, and legal/privacy review.
