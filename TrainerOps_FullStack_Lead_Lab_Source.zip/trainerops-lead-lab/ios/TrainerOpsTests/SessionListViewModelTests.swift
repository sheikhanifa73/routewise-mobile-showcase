import XCTest
@testable import TrainerOps

@MainActor
final class SessionListViewModelTests: XCTestCase {
    func testLoadShowsSeededSessions() async {
        let viewModel = SessionListViewModel(repository: PreviewSessionRepository())
        await viewModel.load()
        guard case let .content(sessions, stale) = viewModel.state else {
            return XCTFail("Expected content")
        }
        XCTAssertEqual(sessions.count, 3)
        XCTAssertFalse(stale)
    }
}
