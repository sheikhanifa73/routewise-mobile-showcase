import Foundation
actor APIClient {
    let baseURL = URL(string: "http://localhost:8000/api/v1")!
    func request<T: Decodable>(_ path: String, method: String = "GET", idempotencyKey: UUID? = nil) async throws -> T {
        var request = URLRequest(url: baseURL.appending(path: path)); request.httpMethod = method
        request.timeoutInterval = 20; request.setValue("application/json", forHTTPHeaderField: "Accept")
        if let idempotencyKey { request.setValue(idempotencyKey.uuidString, forHTTPHeaderField: "Idempotency-Key") }
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let http = response as? HTTPURLResponse else { throw SessionError.server }
        guard 200..<300 ~= http.statusCode else { throw http.statusCode == 401 ? SessionError.unauthenticated : SessionError.server }
        return try JSONDecoder.trainerOps.decode(T.self, from: data)
    }
}
extension JSONDecoder { static var trainerOps: JSONDecoder { let d = JSONDecoder(); d.dateDecodingStrategy = .iso8601; return d } }
