import Foundation
struct TrainingSession: Codable, Identifiable, Equatable { let id: UUID; let title: String; let startsAt: Date; let capacity: Int; let confirmedBookings: Int }
enum SessionError: LocalizedError { case offline, unauthenticated, validation(String), server; var errorDescription: String? { switch self { case .offline: return "You are offline. Your last schedule is shown."; case .unauthenticated: return "Please sign in again."; case .validation(let m): return m; case .server: return "Something went wrong. Please try again." } } }
enum LoadState<T> { case idle, loading, content(T, isStale: Bool), error(String); var isLoading: Bool { if case .loading = self { return true }; return false } }
