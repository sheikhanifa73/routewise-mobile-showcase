import SwiftUI

enum AppRole: String, CaseIterable, Identifiable {
    case client = "Client"
    case trainer = "Trainer"
    case studio = "Studio"
    var id: String { rawValue }
    var subtitle: String {
        switch self {
        case .client: return "Book sessions and manage your credits"
        case .trainer: return "Plan your day and prepare for clients"
        case .studio: return "Monitor capacity and operational health"
        }
    }
    var icon: String {
        switch self { case .client: return "figure.run"; case .trainer: return "figure.strengthtraining.traditional"; case .studio: return "chart.xyaxis.line" }
    }
}

struct TrainerOpsDashboardView: View {
    @StateObject private var viewModel: SessionListViewModel
    @State private var role: AppRole = .client
    @State private var showProfile = false
    @State private var lastSynced = Date()

    init(repository: SessionRepository) {
        _viewModel = StateObject(wrappedValue: SessionListViewModel(repository: repository))
    }

    var body: some View {
        NavigationStack {
            ZStack {
                Color(.systemGroupedBackground).ignoresSafeArea()
                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        hero
                        syncStatus
                        Picker("Role", selection: $role) {
                            ForEach(AppRole.allCases) { Text($0.rawValue).tag($0) }
                        }
                        .pickerStyle(.segmented)
                        roleContent
                    }
                    .padding()
                }
            }
            .navigationTitle("TrainerOps")
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button { Task { await refresh() } } label: { Image(systemName: "arrow.clockwise") }
                        .accessibilityLabel("Refresh schedule")
                }
                ToolbarItem(placement: .topBarTrailing) {
                    Button { showProfile = true } label: { Image(systemName: "person.crop.circle.fill") }
                }
            }
            .task { await refresh() }
            .sheet(isPresented: $showProfile) { ProfileSheet(role: role) }
            .alert("Booking update", isPresented: Binding(get: { viewModel.bookingMessage != nil }, set: { if !$0 { viewModel.bookingMessage = nil } })) {
                Button("Done") { viewModel.bookingMessage = nil }
            } message: { Text(viewModel.bookingMessage ?? "") }
        }
    }

    private func refresh() async {
        await viewModel.load()
        lastSynced = Date()
    }

    private var syncStatus: some View {
        HStack(spacing: 8) {
            Image(systemName: "checkmark.seal.fill").foregroundStyle(.green)
            Text("Live schedule") .font(.footnote.weight(.semibold))
            Text("Synced \(lastSynced, format: .dateTime.hour().minute())") .font(.footnote).foregroundStyle(.secondary)
            Spacer()
            Text("Dubai · GST") .font(.caption.weight(.medium)).foregroundStyle(.secondary)
        }
        .padding(.horizontal, 4)
    }

    private var hero: some View {
        HStack(alignment: .top) {
            VStack(alignment: .leading, spacing: 7) {
                Text("GOOD EVENING").font(.caption.weight(.bold)).foregroundStyle(.white.opacity(0.72))
                Text(role == .client ? "Move better today." : role == .trainer ? "Your coaching day." : "Studio pulse.")
                    .font(.title2.bold()).foregroundStyle(.white)
                Text(role.subtitle).font(.subheadline).foregroundStyle(.white.opacity(0.82))
            }
            Spacer()
            Image(systemName: role.icon).font(.system(size: 31, weight: .semibold)).foregroundStyle(.white)
        }
        .padding(20)
        .background(LinearGradient(colors: [.indigo, .blue, .cyan], startPoint: .topLeading, endPoint: .bottomTrailing))
        .clipShape(RoundedRectangle(cornerRadius: 24))
        .shadow(color: .blue.opacity(0.25), radius: 16, y: 8)
    }

    @ViewBuilder private var roleContent: some View {
        switch role {
        case .client: clientDashboard
        case .trainer: trainerDashboard
        case .studio: studioDashboard
        }
    }

    private var clientDashboard: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(spacing: 12) {
                MetricCard(title: "Credits", value: "8", note: "2 expire in 14 days", tint: .indigo)
                MetricCard(title: "Streak", value: "4", note: "weeks active", tint: .orange)
            }
            sectionTitle("Recommended sessions", "See all")
            sessionCards
        }
    }

    private var trainerDashboard: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(spacing: 12) {
                MetricCard(title: "Today", value: "6", note: "sessions planned", tint: .blue)
                MetricCard(title: "Fill rate", value: "82%", note: "this week", tint: .green)
            }
            sectionTitle("Today’s schedule", "Calendar")
            sessionCards
        }
    }

    private var studioDashboard: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(spacing: 12) {
                MetricCard(title: "Bookings", value: "42", note: "today", tint: .purple)
                MetricCard(title: "Waitlist", value: "5", note: "needs action", tint: .orange)
            }
            sectionTitle("Live capacity", "Operations")
            sessionCards
        }
    }

    private func sectionTitle(_ title: String, _ action: String) -> some View {
        HStack { Text(title).font(.title3.bold()); Spacer(); Button(action) {}.font(.subheadline.weight(.semibold)) }
    }

    @ViewBuilder private var sessionCards: some View {
        switch viewModel.state {
        case .idle, .loading:
            ScheduleSkeleton()
        case .error(let message):
            ContentUnavailableView {
                Label("Schedule unavailable", systemImage: "wifi.exclamationmark")
            } description: {
                Text(message)
            } actions: {
                Button("Try again") { Task { await refresh() } }.buttonStyle(.borderedProminent)
            }
        case .content(let sessions, _):
            ForEach(sessions) { session in
                SessionCard(session: session, role: role, isBooking: viewModel.bookingSessionID == session.id) {
                    Task { await viewModel.book(session.id) }
                }
            }
        }
    }
}

private struct SessionCard: View {
    let session: TrainingSession
    let role: AppRole
    let isBooking: Bool
    let book: () -> Void
    var isFull: Bool { session.confirmedBookings >= session.capacity }
    var body: some View {
        VStack(alignment: .leading, spacing: 13) {
            HStack {
                Text(session.startsAt, format: .dateTime.hour().minute()).font(.caption.weight(.bold)).foregroundStyle(.indigo)
                Spacer()
                Text(isFull ? "WAITLIST" : "\(session.capacity - session.confirmedBookings) SPOTS")
                    .font(.caption2.weight(.bold)).foregroundStyle(isFull ? .orange : .green)
            }
            Text(session.title).font(.headline)
            HStack { Label("Downtown Studio", systemImage: "mappin.and.ellipse"); Spacer(); Text("\(session.confirmedBookings)/\(session.capacity)") }
                .font(.subheadline).foregroundStyle(.secondary)
            if role == .client {
                Button(action: book) {
                    if isBooking { ProgressView().tint(.white) }
                    else { Label(isFull ? "Join waitlist" : "Reserve session", systemImage: isFull ? "person.2.badge.plus" : "checkmark.circle.fill") }
                }
                    .buttonStyle(.borderedProminent).tint(isFull ? .orange : .indigo).frame(maxWidth: .infinity).disabled(isBooking)
            } else {
                Divider()
                Text(role == .trainer ? "Client notes and attendance ready" : "Capacity and trainer coverage monitored")
                    .font(.footnote).foregroundStyle(.secondary)
            }
        }
        .padding(17).background(.background).clipShape(RoundedRectangle(cornerRadius: 18))
        .overlay(RoundedRectangle(cornerRadius: 18).stroke(.quaternary))
    }
}

private struct ScheduleSkeleton: View {
    var body: some View {
        VStack(spacing: 14) {
            ForEach(0..<3, id: \.self) { _ in
                VStack(alignment: .leading, spacing: 12) {
                    Capsule().fill(.quaternary).frame(width: 92, height: 11)
                    RoundedRectangle(cornerRadius: 5).fill(.quaternary).frame(width: 220, height: 20)
                    Capsule().fill(.quaternary).frame(height: 12)
                    RoundedRectangle(cornerRadius: 10).fill(.quaternary).frame(height: 42)
                }.padding(17).background(.background).clipShape(RoundedRectangle(cornerRadius: 18))
            }
        }.redacted(reason: .placeholder).accessibilityLabel("Loading schedule")
    }
}

private struct MetricCard: View {
    let title: String; let value: String; let note: String; let tint: Color
    var body: some View {
        VStack(alignment: .leading, spacing: 5) { Text(title).font(.caption).foregroundStyle(.secondary); Text(value).font(.title.bold()).foregroundStyle(tint); Text(note).font(.caption2).foregroundStyle(.secondary) }
            .frame(maxWidth: .infinity, alignment: .leading).padding(15).background(.background).clipShape(RoundedRectangle(cornerRadius: 16))
    }
}

private struct ProfileSheet: View {
    let role: AppRole
    var body: some View { NavigationStack { List { Section("Account") { Label("Aisha Rahman", systemImage: "person.fill"); Label("Dubai, United Arab Emirates", systemImage: "mappin") }; Section("Current mode") { Label(role.rawValue, systemImage: role.icon) } }.navigationTitle("Profile") } }
}
