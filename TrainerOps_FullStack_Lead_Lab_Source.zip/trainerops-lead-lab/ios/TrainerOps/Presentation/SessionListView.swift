import SwiftUI

struct SessionListView: View {
    @StateObject var viewModel: SessionListViewModel

    var body: some View {
        NavigationStack {
            Group {
                switch viewModel.state {
                case .idle, .loading:
                    ProgressView("Loading sessions")
                case .error(let message):
                    ContentUnavailableView("Could not load sessions", systemImage: "wifi.exclamationmark", description: Text(message))
                case .content(let sessions, let stale):
                    List {
                        if stale {
                            Label("Showing cached schedule", systemImage: "clock.arrow.circlepath")
                                .foregroundStyle(.orange)
                        }
                        ForEach(sessions) { session in
                            HStack(spacing: 12) {
                                VStack(alignment: .leading, spacing: 4) {
                                    Text(session.title).font(.headline)
                                    Text(session.startsAt, style: .time).foregroundStyle(.secondary)
                                    Text("\(session.confirmedBookings) of \(session.capacity) booked")
                                        .font(.caption).foregroundStyle(.secondary)
                                }
                                Spacer()
                                Button("Book") { Task { await viewModel.book(session.id) } }
                                    .buttonStyle(.borderedProminent)
                                    .disabled(session.confirmedBookings >= session.capacity)
                            }
                            .padding(.vertical, 4)
                        }
                    }
                }
            }
            .navigationTitle("TrainerOps")
            .task { await viewModel.load() }
        }
    }
}
