import Foundation
protocol SessionRepository { func sessions() async throws -> (items: [TrainingSession], stale: Bool); func book(_ id: UUID, key: UUID) async throws }
@MainActor final class SessionListViewModel: ObservableObject {
 @Published private(set) var state: LoadState<[TrainingSession]> = .idle
 private let repository: SessionRepository
 init(repository: SessionRepository) { self.repository = repository }
 func load() async { state = .loading; do { let value = try await repository.sessions(); state = .content(value.items, isStale: value.stale) } catch { state = .error(error.localizedDescription) } }
 func book(_ id: UUID) async { guard !state.isLoading else { return }; do { try await repository.book(id, key: UUID()); await load() } catch { state = .error(error.localizedDescription) } }
}
final class PreviewSessionRepository: SessionRepository {
    private var items = [
        TrainingSession(id: UUID(), title: "Strength Foundations", startsAt: .now.addingTimeInterval(3_600), capacity: 8, confirmedBookings: 5),
        TrainingSession(id: UUID(), title: "Mobility Reset", startsAt: .now.addingTimeInterval(7_200), capacity: 12, confirmedBookings: 11),
        TrainingSession(id: UUID(), title: "Performance Coaching", startsAt: .now.addingTimeInterval(10_800), capacity: 4, confirmedBookings: 2)
    ]
    func sessions() async throws -> (items: [TrainingSession], stale: Bool) { (items, false) }
    func book(_ id: UUID, key: UUID) async throws {
        guard let index = items.firstIndex(where: { $0.id == id }), items[index].confirmedBookings < items[index].capacity else { throw SessionError.validation("This session is already full.") }
        let session = items[index]
        items[index] = TrainingSession(id: session.id, title: session.title, startsAt: session.startsAt, capacity: session.capacity, confirmedBookings: session.confirmedBookings + 1)
    }
}
