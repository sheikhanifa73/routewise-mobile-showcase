import SwiftUI

@main
struct TrainerOpsApp: App {
    var body: some Scene {
        WindowGroup {
            TrainerOpsDashboardView(repository: PreviewSessionRepository())
        }
    }
}
