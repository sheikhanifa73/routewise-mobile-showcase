import SwiftUI

@main
struct TrainerOpsApp: App {
    var body: some Scene {
        WindowGroup {
            SessionListView(viewModel: .init(repository: PreviewSessionRepository()))
        }
    }
}
