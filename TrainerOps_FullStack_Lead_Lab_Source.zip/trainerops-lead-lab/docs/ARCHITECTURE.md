# TrainerOps SaaS architecture

TrainerOps is a generic, original portfolio lab for a multi-studio personal-training business. It demonstrates the technical approach needed for a consumer app, trainer app, admin panel, and API without reproducing any employer's product, data, or brand.

## Product surfaces

| Surface | Primary user | Responsibilities |
| --- | --- | --- |
| iOS SwiftUI | client and trainer | session discovery, booking, schedule, account state |
| Android Kotlin/Compose | client and trainer | parity with iOS through the same API contract |
| Laravel API | all clients/admin | authorization, booking integrity, subscriptions, audit events |
| Admin panel (future) | studio operations | sessions, trainer onboarding, attendance, refunds, reporting |

## Request path

`SwiftUI/Compose screen → ViewModel → repository → HTTPS API → Sanctum auth + tenant + RBAC middleware → Laravel service → MySQL transaction → audit/event → notification worker`

The UI never talks directly to database code. The booking service owns concurrency and idempotency: a network retry with the same key returns the original booking rather than taking a second seat.

## SaaS tenancy and roles

- `tenant_id` scopes every studio-owned record; never trust a tenant id sent by the client.
- roles are **customer**, **trainer**, **studio_admin**, and **platform_admin**; policies enforce the action at the API boundary.
- subscription state belongs to a tenant or customer entitlement, not to a mobile screen. Stripe/Tabby/Tamara webhooks verify signatures, enqueue work, and update entitlement state atomically.
- admin reports read from scoped queries and an audit log. Sensitive actions record actor, tenant, target, timestamp, and correlation id.

## Reliability, performance, and battery

- PHP transaction + `lockForUpdate()` prevents overselling a final slot.
- `Idempotency-Key` makes booking retries safe.
- paginated, indexed session queries; ETag/cache headers for read-only schedules; invalidate cached schedule after mutation.
- mobile uses short timeouts, cancellation, exponential backoff for safe reads, and a constrained offline queue only for approved actions.
- no background polling. Use push notifications for booking changes and schedule refresh only after a relevant event, protecting battery and API cost.
- crash reporting, structured logs, API correlation IDs, metrics, and alert thresholds are required before release.

## AWS and release approach

| Area | Production approach |
| --- | --- |
| API | Laravel container on ECS/EC2 behind ALB, autoscaling and health checks |
| Database | RDS MySQL, private subnet, backups, point-in-time recovery |
| Files | private S3 buckets, pre-signed upload URLs, lifecycle policy |
| Async work | SQS + Laravel queue workers; retries and dead-letter queue |
| Secrets | AWS Secrets Manager; no keys in app source or Git |
| CI/CD | GitHub Actions: lint, unit tests, API tests, build; Fastlane signs and distributes release candidates |

## Interview demo: 90 seconds

1. Open iOS or Android: three seed sessions load without a backend so the UI can be reviewed immediately.
2. Book a session: the local UI updates; explain the production request carries an idempotency key.
3. Show `BookingService.php`: transaction, row lock, tenant scope, capacity check.
4. Show the deployment table and explain why secrets, payment webhooks, and observability stay server-side.
