# TrainerOps Lead Lab

Start with [BOOTSTRAP.md](BOOTSTRAP.md) for the exact Xcode, Android Studio, and Laravel setup flow. This archive supplies architecture modules; generated framework shells and credentials are intentionally excluded.

## Run the native demos immediately

- **iOS:** Open `ios/TrainerOps.xcodeproj`, choose any installed iPhone simulator, and press Run. The app has safe local seed data, so it works before the API is connected.
- **Android:** Open the `android` directory in Android Studio. Copy `local.properties.example` to `local.properties`, set your local SDK location, allow Gradle Sync to finish, choose an emulator, then press Run. It also starts with safe local seed data.

Both apps use the same MVVM boundary as the API-connected version: View → ViewModel → Repository. Replace only `PreviewSessionRepository` when the Laravel API is ready.

The upgraded UI includes Client, Trainer, and Studio modes with role-specific metrics, booking/waitlist states, and product-grade empty/loading/error handling. The Laravel module now also includes an entitlement/webhook boundary and audit-event migration for subscriptions.

## Full-stack SaaS showcase

Read [Architecture](docs/ARCHITECTURE.md) before demonstrating the project in an interview. It maps the original TrainerOps lab to the key technical requirements of a multi-tenant fitness SaaS: roles, bookings, subscriptions/payments, security, AWS, CI/CD, performance, reliability, and release engineering.

An interview-ready, full-stack reference implementation for a fitness SaaS. It is a personal learning project with synthetic data, not MyPT software or data.

## What it demonstrates

- Native **SwiftUI iOS** booking UI using MVVM, an actor-backed API client, typed errors, cache fallback and an idempotent booking write.
- Native **Kotlin Android** equivalent using ViewModel, coroutines, repository boundaries and UI state.
- **Laravel/PHP API** with tenant-aware routes, role policy, request validation, idempotency and a transaction-safe booking service.
- **MySQL** schema for studios, users, sessions and bookings.
- Docker Compose setup and test cases that make the expected behavior explicit.

## Setup — line by line

### 1. Start backend services

```bash
cd backend
cp .env.example .env
docker compose up -d
docker compose exec app php artisan key:generate
docker compose exec app php artisan migrate --seed
docker compose exec app php artisan test
```

`docker compose up -d` starts PHP, MySQL and Redis. `migrate --seed` creates synthetic tenant/users/sessions. Never commit `.env`, API secrets or signing files.

### 2. Run iOS

```bash
open ios/TrainerOps.xcodeproj
```

In `APIClient.swift`, set `baseURL` to the API host reachable from the simulator. Run on iOS 17+. Use an `xcconfig` or CI secret for real URLs/tokens; this example intentionally has no credentials.

### 3. Run Android

```bash
cd android
./gradlew installDebug
```

Set the emulator API host in `BuildConfig.API_BASE_URL`; use `10.0.2.2` for a local backend. Never embed service secrets in an APK.

## Interview walkthrough

1. Toggle the TrainerOps web demo offline and show why a cached *read* is safe while a booking write is queued only with an idempotency key.
2. Open `BookingService.php`: a DB transaction locks session capacity, checks duplicate `Idempotency-Key`, then creates exactly one booking.
3. Compare `BookSessionViewModel.swift` and `BookingViewModel.kt`: both screens own UI state; neither knows HTTP or SQL.
4. Explain that production improvements come after metrics: crash-free rate, p95 API latency, booking conversion, frame time and battery impact.

## Production checklist

- Authenticate with short-lived access tokens; store them in Keychain/Keystore, not UserDefaults/SharedPreferences.
- Authorize every resource server-side by tenant and role. Client checks only improve UX.
- Use HTTPS, PII-safe logs, pagination, cancellation, image caching and push/targeted refresh instead of polling.
- Test duplicate booking, capacity race, expired session, offline recovery, deep link, background/foreground and failed payment scenarios.
