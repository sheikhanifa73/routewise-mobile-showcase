<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

final class EnsureTenant
{
    public function handle(Request $request, Closure $next): Response
    {
        abort_unless($request->user()?->tenant_id, 403, 'Tenant context is required.');
        return $next($request);
    }
}
