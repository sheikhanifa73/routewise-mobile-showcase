<?php

namespace App\Http\Controllers;

use App\Models\TrainingSession;
use App\Services\BookingService;
use Illuminate\Http\Request;

final class BookingController extends Controller
{
    public function store(Request $request, TrainingSession $session, BookingService $bookings)
    {
        $data = $request->validate([
            'notes' => ['nullable', 'string', 'max:500'],
            'client_timezone' => ['nullable', 'timezone'],
            'source' => ['required', 'in:ios,android,web'],
        ]);
        $key = $request->header('Idempotency-Key');
        abort_unless(is_string($key) && preg_match('/^[A-Za-z0-9-]{16,128}$/', $key), 422, 'A valid Idempotency-Key is required.');

        // Policy must enforce tenant and consumer/trainer authorization server-side.
        $this->authorize('book', $session);
        $booking = $bookings->create($request->user(), $session, $key, $data['notes'] ?? null);

        return response()->json([
            'data' => $booking,
            'meta' => ['idempotent' => ! $booking->wasRecentlyCreated, 'server_time' => now()->toIso8601String()],
        ], $booking->wasRecentlyCreated ? 201 : 200);
    }
}
