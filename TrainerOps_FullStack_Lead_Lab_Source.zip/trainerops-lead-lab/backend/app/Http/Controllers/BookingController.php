<?php

namespace App\Http\Controllers;

use App\Models\TrainingSession;
use App\Services\BookingService;
use Illuminate\Http\Request;

final class BookingController extends Controller
{
    public function store(Request $request, TrainingSession $session, BookingService $bookings)
    {
        $data = $request->validate(['notes' => ['nullable', 'string', 'max:500']]);
        $key = $request->header('Idempotency-Key');
        abort_unless(is_string($key) && strlen($key) >= 16, 422, 'Idempotency-Key is required.');

        // Policy must enforce tenant and consumer/trainer authorization server-side.
        $this->authorize('book', $session);
        $booking = $bookings->create($request->user(), $session, $key, $data['notes'] ?? null);

        return response()->json($booking, $booking->wasRecentlyCreated ? 201 : 200);
    }
}
