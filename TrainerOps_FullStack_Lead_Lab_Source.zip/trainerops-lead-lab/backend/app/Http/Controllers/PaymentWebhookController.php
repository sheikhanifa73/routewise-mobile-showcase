<?php

namespace App\Http\Controllers;

use App\Services\SubscriptionService;
use Illuminate\Http\Request;

final class PaymentWebhookController extends Controller
{
    public function store(Request $request, SubscriptionService $subscriptions)
    {
        // In production use the provider SDK's signature verifier. Never trust the JSON body alone.
        abort_unless(hash_equals((string) config('services.payments.webhook_secret'), (string) $request->header('X-Webhook-Secret')), 401);
        $data = $request->validate([
            'tenant_id' => ['required', 'integer'], 'subscription_id' => ['required', 'string', 'max:120'],
            'provider' => ['required', 'in:stripe,tabby,tamara'], 'plan_code' => ['required', 'string'],
            'status' => ['required', 'in:active,past_due,canceled,trialing'], 'user_id' => ['nullable', 'integer'], 'renews_at' => ['nullable', 'date'],
        ]);
        $subscriptions->sync($data);
        return response()->json(['received' => true], 202);
    }
}
