<?php

namespace App\Http\Controllers;

use App\Models\TrainingSession;
use Illuminate\Http\Request;

final class SessionController extends Controller
{
    public function index(Request $request)
    {
        return TrainingSession::query()
            ->where('tenant_id', $request->user()->tenant_id)
            ->where('starts_at', '>=', now())
            ->orderBy('starts_at')
            ->paginate(20);
    }
}
