<?php

namespace App\Services;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

final class SubscriptionService
{
    /** Webhook payloads are idempotent: a repeated provider event updates one entitlement. */
    public function sync(array $event): void
    {
        DB::transaction(function () use ($event) {
            DB::table('subscriptions')->updateOrInsert(
                ['provider_subscription_id' => $event['subscription_id']],
                [
                    'tenant_id' => $event['tenant_id'], 'user_id' => $event['user_id'] ?? null,
                    'provider' => $event['provider'], 'plan_code' => $event['plan_code'],
                    'status' => $event['status'], 'renews_at' => $event['renews_at'] ?? null,
                    'updated_at' => now(), 'created_at' => now(),
                ]
            );
            DB::table('audit_events')->insert([
                'tenant_id' => $event['tenant_id'], 'actor_id' => null, 'event_type' => 'subscription.synced',
                'subject_type' => 'subscription', 'subject_id' => null, 'correlation_id' => (string) Str::uuid(),
                'metadata' => json_encode(['provider' => $event['provider'], 'status' => $event['status']]),
                'created_at' => now(), 'updated_at' => now(),
            ]);
        });
    }
}
