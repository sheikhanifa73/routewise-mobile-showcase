<?php

namespace App\Services;

use App\Models\Booking;
use App\Models\TrainingSession;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

final class BookingService
{
    public function create(User $user, TrainingSession $session, string $key, ?string $notes): Booking
    {
        return DB::transaction(function () use ($user, $session, $key, $notes) {
            // Replaying the same request returns the original result, never a second booking.
            $existing = Booking::where('idempotency_key', $key)->first();
            if ($existing) return $existing;

            // Lock prevents two customers taking the final seat concurrently.
            $locked = TrainingSession::lockForUpdate()->findOrFail($session->id);
            if ($locked->bookings()->where('status', 'confirmed')->count() >= $locked->capacity) {
                throw ValidationException::withMessages(['session' => 'This session is full.']);
            }
            return Booking::create([
                'tenant_id' => $user->tenant_id, 'user_id' => $user->id,
                'training_session_id' => $locked->id, 'idempotency_key' => $key,
                'notes' => $notes, 'status' => 'confirmed',
            ]);
        }, 3);
    }
}
