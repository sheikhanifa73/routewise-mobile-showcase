<?php
namespace Tests\Feature;
use Tests\TestCase;
class BookingTest extends TestCase {
 public function test_same_idempotency_key_returns_one_booking(): void {
   // Seed a tenant, authenticated consumer and future session with capacity 1.
   // POST twice with same Idempotency-Key; assert second response is 200 and DB has one booking.
   $this->markTestIncomplete('Wire to project factories before running.');
 }
}
