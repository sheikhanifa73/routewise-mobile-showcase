<?php

use App\Http\Controllers\BookingController;
use App\Http\Controllers\SessionController;
use Illuminate\Support\Facades\Route;

Route::middleware(['auth:sanctum', 'tenant'])->group(function () {
    Route::get('/v1/sessions', [SessionController::class, 'index']);
    Route::post('/v1/sessions/{session}/bookings', [BookingController::class, 'store'])
        ->middleware('throttle:bookings');
});
