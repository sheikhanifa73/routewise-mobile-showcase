<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
return new class extends Migration {
 public function up(): void {
  Schema::create('training_sessions', function (Blueprint $t) { $t->id(); $t->foreignId('tenant_id')->index(); $t->foreignId('trainer_id')->index(); $t->string('title'); $t->timestamp('starts_at')->index(); $t->unsignedSmallInteger('capacity'); $t->timestamps(); });
  Schema::create('bookings', function (Blueprint $t) { $t->id(); $t->foreignId('tenant_id')->index(); $t->foreignId('user_id')->index(); $t->foreignId('training_session_id')->index(); $t->uuid('idempotency_key')->unique(); $t->string('status'); $t->text('notes')->nullable(); $t->timestamps(); });
 }
 public function down(): void { Schema::dropIfExists('bookings'); Schema::dropIfExists('training_sessions'); }
};
