# RouteWise Mobile Showcase

RouteWise is a delivery-operations portfolio product for a UAE-style dispatch workflow. It demonstrates the same active-delivery experience in three clients:

- `ios-native/`: SwiftUI, MVVM-style view model, async repository, visible loading/error/data states.
- `flutter/`: Flutter/Dart dashboard with typed delivery data and reusable cards.
- `react-native/`: React Native/TypeScript dashboard using hooks and typed models.
- `docs/`: a static product showcase that can be published with GitHub Pages.

## What to tell an interviewer

“I built RouteWise to compare native iOS and cross-platform client choices on one delivery workflow. The native iOS client uses SwiftUI and an async repository. The Flutter and React Native clients show that I understand cross-platform structure as well. I would choose native iOS for deep Apple-platform integration and cross-platform where product speed and shared features justify it.”

Do **not** say you have professional React Native experience unless that is true. Present it as a portfolio project.

## Run locally

1. **iOS**: Create an Xcode iOS App named `RouteWise` using SwiftUI, then add the files in `ios-native/RouteWise/` to the app target.
2. **Flutter**: Run `flutter create .` inside `flutter/`, restore the supplied `lib/main.dart`, then run `flutter run`.
3. **React Native**: Create an Expo TypeScript app, replace `App.tsx` with `react-native/App.tsx`, then run `npx expo start`.
4. **Showcase page**: open `docs/index.html` in a browser.

## Publish to GitHub

Create a public repository called `routewise-mobile-showcase`, commit these files, and push `main`. In the repository settings, enable **Pages** from GitHub Actions. The included workflow publishes the browser showcase at:

`https://sheikhanifa73.github.io/routewise-mobile-showcase/`

Pin this repository and add the public link to LinkedIn Featured after it is live.
