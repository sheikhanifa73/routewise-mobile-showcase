import { SafeAreaView, StyleSheet, Text, View } from 'react-native';

type Delivery = { reference: string; area: string; status: string; eta: number };
const deliveries: Delivery[] = [
  { reference: 'RW-204', area: 'Dubai Marina', status: 'Driver assigned', eta: 18 },
  { reference: 'RW-205', area: 'Business Bay', status: 'Preparing', eta: 35 },
];

export default function App() {
  return <SafeAreaView style={styles.screen}><Text style={styles.title}>RouteWise</Text><Text style={styles.subtitle}>Active deliveries</Text>{deliveries.map((delivery) => <View key={delivery.reference} style={styles.card}><View><Text style={styles.reference}>{delivery.reference}</Text><Text>{delivery.area}</Text><Text style={styles.muted}>ETA: {delivery.eta} min</Text></View><Text style={styles.status}>{delivery.status}</Text></View>)}</SafeAreaView>;
}
const styles = StyleSheet.create({ screen: { flex: 1, padding: 20, backgroundColor: '#F8FAFC' }, title: { fontSize: 30, fontWeight: '700' }, subtitle: { marginTop: 4, marginBottom: 18, color: '#64748B' }, card: { backgroundColor: 'white', borderRadius: 12, padding: 16, marginBottom: 12, flexDirection: 'row', justifyContent: 'space-between', shadowColor: '#0F172A', shadowOpacity: .08, shadowRadius: 8 }, reference: { fontSize: 17, fontWeight: '700', marginBottom: 4 }, muted: { color: '#64748B', marginTop: 4 }, status: { color: '#D97706', fontWeight: '600' } });
