import SwiftUI

struct Delivery: Identifiable, Hashable {
    let id = UUID(); let reference: String; let area: String; let status: String; let etaMinutes: Int
}

protocol DeliveryRepository { func activeDeliveries() async throws -> [Delivery] }
struct DemoDeliveryRepository: DeliveryRepository {
    func activeDeliveries() async throws -> [Delivery] {
        try await Task.sleep(for: .milliseconds(350))
        return [Delivery(reference: "RW-204", area: "Dubai Marina", status: "Driver assigned", etaMinutes: 18), Delivery(reference: "RW-205", area: "Business Bay", status: "Preparing", etaMinutes: 35)]
    }
}

@MainActor final class DeliveryViewModel: ObservableObject {
    enum State { case loading, ready([Delivery]), failed }
    @Published private(set) var state: State = .loading
    private let repository: DeliveryRepository
    init(repository: DeliveryRepository) { self.repository = repository }
    func load() async { do { state = .ready(try await repository.activeDeliveries()) } catch { state = .failed } }
}

struct DeliveryDashboard: View {
    @StateObject private var viewModel: DeliveryViewModel
    init(viewModel: DeliveryViewModel) { _viewModel = StateObject(wrappedValue: viewModel) }
    var body: some View {
        NavigationStack {
            Group {
                switch viewModel.state {
                case .loading: ProgressView("Loading active deliveries")
                case .failed: ContentUnavailableView("Unable to load deliveries", systemImage: "exclamationmark.triangle")
                case .ready(let deliveries): List(deliveries) { delivery in
                    VStack(alignment: .leading, spacing: 6) { HStack { Text(delivery.reference).font(.headline); Spacer(); Text(delivery.status).foregroundStyle(.orange) }; Text(delivery.area).foregroundStyle(.secondary); Text("ETA: \(delivery.etaMinutes) min").font(.caption) }
                }
                .listStyle(.plain)
                }
            }
            .navigationTitle("RouteWise")
        }.task { await viewModel.load() }
    }
}
