import SwiftUI

@main
struct RouteWiseApp: App {
    var body: some Scene {
        WindowGroup { DeliveryDashboard(viewModel: DeliveryViewModel(repository: DemoDeliveryRepository())) }
    }
}
