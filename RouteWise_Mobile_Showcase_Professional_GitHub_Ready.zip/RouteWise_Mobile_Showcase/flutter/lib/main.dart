import 'package:flutter/material.dart';

void main() => runApp(const RouteWiseApp());

class Delivery { const Delivery(this.reference, this.area, this.status, this.eta); final String reference, area, status; final int eta; }

class RouteWiseApp extends StatelessWidget {
  const RouteWiseApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(theme: ThemeData(colorSchemeSeed: Colors.indigo, useMaterial3: true), home: const DeliveryDashboard());
}

class DeliveryDashboard extends StatelessWidget {
  const DeliveryDashboard({super.key});
  static const deliveries = [Delivery('RW-204', 'Dubai Marina', 'Driver assigned', 18), Delivery('RW-205', 'Business Bay', 'Preparing', 35)];
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('RouteWise')),
    body: ListView.separated(padding: const EdgeInsets.all(16), itemCount: deliveries.length, separatorBuilder: (_, __) => const SizedBox(height: 12), itemBuilder: (_, index) {
      final d = deliveries[index]; return Card(child: ListTile(title: Text(d.reference), subtitle: Text('${d.area}\nETA: ${d.eta} min'), isThreeLine: true, trailing: Text(d.status, style: const TextStyle(color: Colors.orange)));
    }),
  );
}
